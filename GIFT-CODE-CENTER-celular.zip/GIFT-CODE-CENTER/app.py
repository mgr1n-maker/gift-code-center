import os
from pathlib import Path
from flask import Flask, render_template, request, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import or_

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-change-this")
database_url = os.environ.get("DATABASE_URL", f"sqlite:///{BASE_DIR / 'instance' / 'giftcodes.db'}")
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class GiftCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    platform = db.Column(db.String(80), nullable=False, index=True)
    category = db.Column(db.String(50), nullable=False, index=True)
    code = db.Column(db.String(120), nullable=False, unique=True)
    description = db.Column(db.String(240), nullable=False, default="")
    status = db.Column(db.String(20), nullable=False, default="demo")
    created_at = db.Column(db.DateTime, server_default=db.func.now())

def seed_demo_data():
    if GiftCode.query.first():
        return
    examples = [
        ("Xbox", "Games", "DEMO-XBOX-2026-001", "Código fictício para demonstração."),
        ("PlayStation", "Games", "DEMO-PSN-2026-002", "Código fictício para demonstração."),
        ("Steam", "Games", "DEMO-STEAM-2026-003", "Código fictício para demonstração."),
        ("Google Play", "Apps", "DEMO-GPLAY-2026-004", "Código fictício para demonstração."),
        ("Roblox", "Games", "DEMO-ROBLOX-2026-005", "Código fictício para demonstração."),
    ]
    for platform, category, code, description in examples:
        db.session.add(GiftCode(platform=platform, category=category, code=code,
                                description=description, status="demo"))
    db.session.commit()

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self'; script-src 'self'; "
        "img-src 'self' data:; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
    )
    return response

@app.route("/")
def index():
    query = request.args.get("q", "").strip()[:80]
    category = request.args.get("category", "").strip()[:50]
    platform = request.args.get("platform", "").strip()[:80]
    statement = GiftCode.query
    if query:
        pattern = f"%{query}%"
        statement = statement.filter(or_(
            GiftCode.platform.ilike(pattern),
            GiftCode.category.ilike(pattern),
            GiftCode.description.ilike(pattern)
        ))
    if category:
        statement = statement.filter_by(category=category)
    if platform:
        statement = statement.filter_by(platform=platform)
    codes = statement.order_by(GiftCode.platform.asc()).all()
    categories = [row[0] for row in db.session.query(GiftCode.category).distinct().order_by(GiftCode.category).all()]
    platforms = [row[0] for row in db.session.query(GiftCode.platform).distinct().order_by(GiftCode.platform).all()]
    return render_template("index.html", codes=codes, query=query,
                           selected_category=category, selected_platform=platform,
                           categories=categories, platforms=platforms)

@app.route("/sobre")
def about():
    return render_template("about.html")

@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="Página não encontrada."), 404

@app.errorhandler(500)
def server_error(_error):
    db.session.rollback()
    return render_template("error.html", code=500, message="Ocorreu um erro interno."), 500

with app.app_context():
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    db.create_all()
    seed_demo_data()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
