# Gift Code Center

Catálogo demonstrativo de plataformas e códigos promocionais fictícios. Projeto em Flask + SQLite, preparado para hospedagem.

## Requisitos
- Python 3.11 ou superior
- pip

## Executar localmente (Windows)
1. Extraia a pasta do projeto.
2. Abra o terminal dentro de `GIFT-CODE-CENTER`.
3. Crie o ambiente: `py -m venv .venv`
4. Ative: `.venv\Scripts\activate`
5. Instale: `pip install -r requirements.txt`
6. Execute: `python app.py`
7. Abra `http://127.0.0.1:5000`.

No macOS/Linux, use `python3 -m venv .venv` e `source .venv/bin/activate`.

## Hospedar no Render
1. Crie uma conta no Render e um repositório Git com estes arquivos.
2. Envie o projeto ao GitHub.
3. No Render, escolha **New > Blueprint** e conecte o repositório.
4. O Render lerá `render.yaml`, instalará dependências e iniciará Gunicorn.
5. O arquivo `render.yaml` configura um Web Service no plano gratuito.
6. Neste modo, o SQLite fica no armazenamento temporário do serviço. Como o catálogo inicial contém apenas exemplos fictícios e não há painel administrativo, isso serve para testar o site. Dados adicionados futuramente podem ser perdidos em reinicializações ou novos deploys. Para guardar dados permanentemente, será necessário migrar para um banco gerenciado ou contratar armazenamento persistente.

## Variáveis
- `SECRET_KEY`: chave aleatória longa para o ambiente.
- `DATABASE_URL`: caminho SQLite ou URL de banco compatível.

## Como os dados funcionam
Na primeira inicialização, o app cria `instance/giftcodes.db` e insere exemplos fictícios. Se o banco já tiver registros, não repete a carga inicial. Esta versão não tem painel administrativo nem rota pública para inserir códigos.

Para adicionar registros reais, use apenas códigos que você recebeu legitimamente e mantenha o banco atualizado por um processo administrativo seguro. Não publique códigos privados, chaves ou dados pessoais no repositório.

## Segurança e limitações
- `debug=False` por padrão.
- O servidor de produção é Gunicorn, não o servidor de desenvolvimento do Flask.
- Cabeçalhos básicos de segurança estão configurados.
- A interface é somente catálogo: não gera, valida nem resgata códigos.
- Antes de um lançamento público, configure domínio/HTTPS, backups do banco, monitoramento e política de privacidade.
- Não use a `SECRET_KEY` padrão em produção.
